// TO-DO: Add constants NUM_BULBS, SPEED

// Load in pixel data as json
const fs = require('fs');
const data1 = fs.readFileSync('data/loading_green_house.json');
const pixels = JSON.parse(data1);

// Load in score data as json
const data2 = fs.readFileSync('data/home-freqs.json');
const score = JSON.parse(data2);

// Max API
const maxApi = require('max-api');

// Helper function for non-blocking sleep
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// js object to send as max dict
let pixelData = {
  base: [],
  lookahead: [],
  homefr: {}
}

// number of pixels to look ahead
let spread = 3;

maxApi.addHandler('spread', (spreadVal) => {
  spread = spreadVal;
});

// speed of pixel change in ms
let speed = 1000;

maxApi.addHandler('speed', (speedVal) => {
  speed = speedVal;
});

// initialize + get score step
// let homeCount = -1;

// function getFr() {
//     if (homeCount == score.length - 1) {
//         homeCount = 0;
//     } else {
//         homeCount++;
//     }
//     return score[homeCount]
// }

// multiplier set in Max to control duration
let durmult = 1;

maxApi.addHandler('durmult', (durmultVal) => {
	durmult = durmultVal;
});

maxApi.post(durmult);

let scoreIndex = 0;
let frDur = durmult * score[scoreIndex].duration;

maxApi.post(frDur);

function getFr() {
    if (frDur > 0) {
        frDur -= 1; //object repetition
    } else {
        if (scoreIndex == score.length - 1) {
            scoreIndex = 0;
        } else {
            scoreIndex++;
        }
        frDur = (durmult * score[scoreIndex].duration) - 1;
    }

    return score[scoreIndex];
}

// MAIN LOOP FUNCTION

async function makeArt() {

    // Loop
    // Can also add more on to loop to send values beyond the number of bulbs

  // for each pixel's rgb array in pixels[]
  for (let i=0; i<=pixels.length; i++) {

    pixelData.base = pixels[i];
    pixelData.lookahead = pixels[i + spread];
    pixelData.homefr =  getFr();

    maxApi.post(`Pixel ${i}: Base: ${pixelData.base} Look (${spread}): ${pixelData.lookahead} ScoreStep: ${pixelData.homefr.step} Duration: ${frDur}`);

    maxApi.outlet(pixelData);

    await sleep(speed); // wait one second
  }

}

makeArt();